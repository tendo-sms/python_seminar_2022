def print_function:
    print("関数print_functionが呼び出されました。")

var1 = "変数1"
var2 = "変数2"
