def print_string():
    print("モジュール「sample_mod2」の関数「print_string」が呼び出されました。")

string_var1 = "モジュール「sample_mod2」で定義された変数「string_var1」が参照されました。"
string_var2 = "モジュール「sample_mod2」で定義された変数「string_var2」が参照されました。"
