def print_string():
    print("モジュール「sample_mod1」の関数「print_string」が呼び出されました。")

string_var = "モジュール「sample_mod1」で定義された変数「string_var」が参照されました。"
